import { Component } from '@angular/core';
import { IonicPage, NavController, LoadingController, NavParams, Loading } from 'ionic-angular';

import { ComplaintbyticketnoPage } from '../complaintbyticketno/complaintbyticketno';
/**
 * Generated class for the ComplaintshistoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-complaintshistory',
  templateUrl: 'complaintshistory.html',
})
export class ComplaintshistoryPage {
  tickets: string = "pending";
  loading: Loading;
  constructor(public navCtrl: NavController, public navParams: NavParams, private loadingCtrl: LoadingController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ComplaintshistoryPage'); 
  }
  public showByTicketNo(){
    this.showLoading();
    this.navCtrl.push(ComplaintbyticketnoPage);
  } 
  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...',
      dismissOnPageChange: true
    });
    this.loading.present();
}

}
