import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ComplaintshistoryPage } from './complaintshistory';

@NgModule({
  declarations: [
    ComplaintshistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(ComplaintshistoryPage),
  ],
})
export class ComplaintshistoryPageModule {}
