import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Loading, LoadingController } from 'ionic-angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { LoginPage } from '../login/login';

/**
 * Generated class for the ResetpasswordPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-resetpassword',
  templateUrl: 'resetpassword.html',
})
export class ResetpasswordPage {
  public resetpassord:resetPasswordDet;
  resetpassordform:FormGroup;
  loading: Loading;

  constructor(public navCtrl: NavController, public navParams: NavParams,private formBuilder: FormBuilder, 
    private loadingCtrl: LoadingController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ResetpasswordPage');
  }
  ngOnInit(){
    this.createresetPasswordForm();
      }

  createresetPasswordForm(){
    this.resetpassordform = this.formBuilder.group({
      newPassword: new FormControl('',Validators.required),
      confirmPassword: new FormControl('',Validators.required),
      oldPassword: new FormControl('',Validators.required),
      userId :0
    
    });
}
public resetpassword(){
  this.showLoading();
  this.navCtrl.setRoot(LoginPage);
}
showLoading() {
  this.loading = this.loadingCtrl.create({
    content: 'Please wait...',
    dismissOnPageChange: true
  });
  this.loading.present();
}
}
interface resetPasswordDet{
  newPassword:string;
  confirmPassword: string;
  oldPassword:string;
}
