import { Component } from '@angular/core';
import { NavController, LoadingController, Loading } from 'ionic-angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HomePage } from '../home/home';
import { RegisterPage } from '../register/register';
import { AlertController } from 'ionic-angular';
import { ResetpasswordPage } from '../resetpassword/resetpassword';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {
public loginform:logindetails;
loginForm:FormGroup;
loading: Loading;
  constructor(public navCtrl: NavController,private formBuilder: FormBuilder, 
    private loadingCtrl: LoadingController,private alertCtrl: AlertController) {

  }
  ngOnInit(){
this.createLoginForm();
  }
createLoginForm(){
  this.loginForm = this.formBuilder.group({
    userName: new FormControl('',Validators.required),
    userPassword: new FormControl('',Validators.required),
    userId :0,
    rememberMe: new FormControl()
  
  });

}


public signIn(){
  this.showLoading();
  this.navCtrl.setRoot(HomePage);
} 
public signUp(){
  this.showLoading();
  this.navCtrl.push(RegisterPage);
} 
showLoading() {
  this.loading = this.loadingCtrl.create({
    content: 'Please wait...',
    dismissOnPageChange: true
  });
  this.loading.present();
}

public promptForgotPassword() {
  let alert = this.alertCtrl.create({
    title: 'FORGOT PASSWORD',
    message: 'Enter your registered email address',
    inputs: [
      {
        name: 'email',
        placeholder: 'Email'
      }
    ],
    buttons: [

      {
        text: 'SUBMIT'
         ,
        handler: data => { this.navCtrl.push(ResetpasswordPage); return true;
          /* if (email.isValid(data.username, data.password)) {
            // logged in!
          } else {
            // invalid login
            return false;
          } */
        } 
      }
    ]
  });
  alert.present();
}

}
interface logindetails{
  userName:string;
  userPassword:string;

}
