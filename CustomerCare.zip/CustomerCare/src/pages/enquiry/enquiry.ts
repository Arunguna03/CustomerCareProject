import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the EnquiryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-enquiry',
  templateUrl: 'enquiry.html',
})
export class EnquiryPage {
actionVal:string;
frmtitle:string="REFERAL ENQUIRY"
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.actionVal=navParams.get('actions');
    //alert(this.actionVal)
    if(this.actionVal != 'referralorder'){
      this.frmtitle = "ORDER";
    }
  }

  ionViewDidLoad() { 
    console.log('ionViewDidLoad EnquiryPage');
  }

 
}
