import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Loading, LoadingController } from 'ionic-angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HomePage } from '../home/home';

/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {

  public userdata:userDetails;
  registerForm:FormGroup;
  loading: Loading;
  constructor(public navCtrl: NavController, public navParams: NavParams,private formBuilder: FormBuilder,private loadingCtrl: LoadingController) {
  }


  ngOnInit(){
    this.createLoginForm();
      }
    createLoginForm(){
      this.registerForm = this.formBuilder.group({
        userfullName: new FormControl('',Validators.required),
        userMobileNo: new FormControl('',Validators.required),
        userEmail: new FormControl('',Validators.required),
        userAddress: new FormControl('',Validators.required),
        zipcode: new FormControl('',Validators.required),
        userName: new FormControl('',Validators.required),
        userId :0,
        agree:new FormControl('',Validators.required)
      });

    }
    public onSubmitUser(){
      this.showLoading();
  this.navCtrl.setRoot(HomePage);
    }


    showLoading() {
      this.loading = this.loadingCtrl.create({
        content: 'Please wait...',
        dismissOnPageChange: true
      });
      this.loading.present();
    }


  ionViewDidLoad() {
    console.log('ionViewDidLoad RegisterPage');
  }

}
interface userDetails{
  userfullName:string;
  userMobileNo: string;
  userEmail: string;
  userName: string;
  userAddress: string;
  userId:Number;
  zipcode: string;
  agree: boolean;

}
