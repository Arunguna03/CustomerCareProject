import { Component } from '@angular/core';
import { NavController ,LoadingController, NavParams, Loading} from 'ionic-angular';
import { ComplaintsPage } from '../complaints/complaints';
import { ComplaintshistoryPage } from '../complaintshistory/complaintshistory';
import { EnquiryPage } from '../enquiry/enquiry';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  loading: Loading;
  constructor(public navCtrl: NavController,private loadingCtrl: LoadingController) {

  }
  public screenNav(actions:string){
    //alert("dsfs"+actions);
    //debugger;
    if(actions == 'createservice'){
      this.showLoading();
      this.navCtrl.push(ComplaintsPage);
    }else if(actions == 'trackservice'){
      this.showLoading();
      this.navCtrl.push(ComplaintshistoryPage);
    }else if(actions == 'referralorder'){
      this.showLoading();
      this.navCtrl.push(EnquiryPage,{
        actions:actions
      });
    }else{
      this.showLoading();
      this.navCtrl.push(EnquiryPage,{
        actions:actions
      });
    }
  } 
  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...',
      dismissOnPageChange: true
    });
    this.loading.present();
}
}
