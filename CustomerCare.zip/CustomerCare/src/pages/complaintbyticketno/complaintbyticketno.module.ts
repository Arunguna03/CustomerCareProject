import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ComplaintbyticketnoPage } from './complaintbyticketno';

@NgModule({
  declarations: [
    ComplaintbyticketnoPage,
  ],
  imports: [
    IonicPageModule.forChild(ComplaintbyticketnoPage),
  ],
})
export class ComplaintbyticketnoPageModule {}
