import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { LoginPage } from '../pages/login/login';
import { RegisterPage } from '../pages/register/register';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { ComplaintsPage } from '../pages/complaints/complaints';
import { ComplaintshistoryPage } from '../pages/complaintshistory/complaintshistory';
import { ComplaintbyticketnoPage} from '../pages/complaintbyticketno/complaintbyticketno';
import { EnquiryPage } from '../pages/enquiry/enquiry';
import { ResetpasswordPage } from '../pages/resetpassword/resetpassword';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
import {MatInputModule,MatButtonModule,MatFormFieldModule,MatIconModule,MatGridListModule,MatCardModule,MatProgressSpinnerModule} from '@angular/material'

@NgModule({
  declarations: [
    LoginPage,
    RegisterPage,
    MyApp,
    HomePage,
    ComplaintsPage,
    ComplaintshistoryPage,
    ComplaintbyticketnoPage,
    EnquiryPage,
    ResetpasswordPage,
    ListPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    BrowserAnimationsModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatGridListModule,
    MatCardModule,
    MatProgressSpinnerModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    LoginPage,
    MyApp,
    HomePage,
    ListPage,
    ComplaintsPage,
    ComplaintshistoryPage,
    ComplaintbyticketnoPage,
    EnquiryPage,
    ResetpasswordPage,
    RegisterPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
